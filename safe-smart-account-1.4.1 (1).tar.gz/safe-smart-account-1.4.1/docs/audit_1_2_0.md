### Audit Results

##### Auditor
* G0 Group (https://github.com/g0-group)
  * Adam Kolář (@adamkolar)
  * Nick Munoz-McDonald (@NickErrant)

##### Notes
The audit was performed on commit [62d4bd39925db65083b035115d6987772b2d2dca](https://github.com/safe-global/safe-contracts/commit/62d4bd39925db65083b035115d6987772b2d2dca)

##### Files
* [Audit Report 1.2.0](Gnosis_Safe_Audit_Report_1_2_0.pdf)
