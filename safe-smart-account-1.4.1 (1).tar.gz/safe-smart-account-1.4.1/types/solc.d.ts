declare module "solc";
